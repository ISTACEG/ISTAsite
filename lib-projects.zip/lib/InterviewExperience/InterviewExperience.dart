import 'package:flutter/material.dart';

class InterviewExperience extends StatefulWidget {
  const InterviewExperience({Key? key}) : super(key: key);

  @override
  _InterviewExperienceState createState() => _InterviewExperienceState();
}

class _InterviewExperienceState extends State<InterviewExperience> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: Center(child: Text("Interview Experience")));
  }
}
